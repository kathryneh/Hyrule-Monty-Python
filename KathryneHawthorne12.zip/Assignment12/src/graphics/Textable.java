package graphics;

public interface Textable extends Graphicable {

	public String getText();

	public void setText(String newString);

}
