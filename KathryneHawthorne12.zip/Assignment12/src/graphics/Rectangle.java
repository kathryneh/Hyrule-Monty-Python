package graphics;

public class Rectangle extends AnimatedObservedGraphic implements Graphicable {

	public Rectangle(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

}
