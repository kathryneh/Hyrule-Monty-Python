package scanner;

public interface InheritedScannable extends Scannable {
	public void characterizeCommand(String commandString);

	//TokenList getTokenList();
}
