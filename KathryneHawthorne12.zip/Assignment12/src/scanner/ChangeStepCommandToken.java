package scanner;

public class ChangeStepCommandToken extends CommandToken {

	public ChangeStepCommandToken(String newInput) {
		super(newInput);
	}

}
