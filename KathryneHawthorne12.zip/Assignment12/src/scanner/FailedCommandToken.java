package scanner;

public class FailedCommandToken extends CommandToken implements Tokenizable {

	public FailedCommandToken(String newInput) {
		super(newInput);
	}

}
