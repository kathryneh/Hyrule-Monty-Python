package scanner;

public class ChangePauseCommandToken extends CommandToken {

	public ChangePauseCommandToken(String newInput) {
		super(newInput);
	}

}
