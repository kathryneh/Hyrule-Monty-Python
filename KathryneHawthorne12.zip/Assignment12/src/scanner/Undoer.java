package scanner;

public interface Undoer {   
    public void undo();
    public void redo();
}
