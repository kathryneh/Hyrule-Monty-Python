package scanner;

public class AnimateCommandToken extends CommandToken implements Tokenizable {

	public AnimateCommandToken(String newInput) {
		super(newInput);
	}

}
