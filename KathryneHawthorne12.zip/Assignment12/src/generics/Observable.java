package generics;

public interface Observable<T> extends GenericCollectable<T> {
	//public void addVectorListener(VectorListener listener);
}

