package scanner;

public interface InheritedScannableHistory extends InheritedScannable {
	public TokenHistory getTokenList();
}
