package scanner;

public class MoveCommandToken extends CommandToken implements Tokenizable {

}
