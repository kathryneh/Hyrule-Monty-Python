package scanner;

public class PassedCommandToken extends CommandToken implements Tokenizable {

}
