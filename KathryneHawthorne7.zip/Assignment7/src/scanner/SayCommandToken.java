package scanner;

public class SayCommandToken extends CommandToken implements Tokenizable {

}
