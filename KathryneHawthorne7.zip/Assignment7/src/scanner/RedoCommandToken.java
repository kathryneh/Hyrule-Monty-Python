package scanner;

public class RedoCommandToken extends CommandToken implements Tokenizable {

}
