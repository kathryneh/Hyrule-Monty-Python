package scanner;

public class UndoCommandToken extends CommandToken implements Tokenizable {

}
