package avatars;

public interface AvatarCollectable extends Collectable {

	public void moveX(int x);
	public void moveY(int y);

}
