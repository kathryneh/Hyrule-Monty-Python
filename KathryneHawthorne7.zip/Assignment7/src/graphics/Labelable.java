package graphics;

public interface Labelable extends Textable {
	public String getImageFileName();

	public void setImageFileName(String newVal);
}
