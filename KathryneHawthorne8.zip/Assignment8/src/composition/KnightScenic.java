package composition;

import avatars.KnightAvatar;

public interface KnightScenic extends Scenic {
	public KnightAvatar getKnight();
	
}
