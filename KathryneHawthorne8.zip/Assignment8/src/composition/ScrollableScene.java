package composition;

public class ScrollableScene extends Scene implements Scenic {
	int scrollX = 0;
	int scrollY = 0;

	public ScrollableScene() {
		super();

	}

	public void setScrollX(int newVal) {
		scrollX = newVal + scrollX;

	}

	public void setScrollY(int newVal) {
		scrollY = newVal + scrollY;
	}
}
