package graphics;

public class Oval extends Graphic implements Graphicable {

	public Oval(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

}
