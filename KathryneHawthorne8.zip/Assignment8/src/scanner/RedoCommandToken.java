package scanner;

public class RedoCommandToken extends CommandToken implements Tokenizable {

	public RedoCommandToken(String newInput) {
		super(newInput);
	}

}
