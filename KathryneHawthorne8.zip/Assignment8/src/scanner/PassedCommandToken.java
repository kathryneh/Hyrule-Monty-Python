package scanner;

public class PassedCommandToken extends CommandToken implements Tokenizable {

	public PassedCommandToken(String newInput) {
		super(newInput);
	}

}
