package scanner;

public interface InheritedScannableList extends InheritedScannable {
	public Listable getTokenList();
}
