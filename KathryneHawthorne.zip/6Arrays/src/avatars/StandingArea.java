package avatars;

import main.Oval;

public interface StandingArea {
	public Oval standingArea();
}
