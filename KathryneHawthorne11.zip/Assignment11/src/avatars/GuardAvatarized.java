package avatars;

import graphics.Rectangle;

public interface GuardAvatarized extends Avatarized {
	public Rectangle getShield();

}
