package scanner;

public interface Object {

	public String getInput();
	public void setReturnedString(String tokenString);
	public void setInput(String newInput);
	public String getReturnedString();
}
