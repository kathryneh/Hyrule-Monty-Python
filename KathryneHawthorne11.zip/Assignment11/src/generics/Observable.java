package generics;

import util.models.VectorListener;

public interface Observable<T> extends GenericCollectable<T> {
	//public void addVectorListener(VectorListener listener);
}

