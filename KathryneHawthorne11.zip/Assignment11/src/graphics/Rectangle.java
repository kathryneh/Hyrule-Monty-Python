package graphics;

public class Rectangle extends ObservedGraphic implements Graphicable {

	public Rectangle(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

}
