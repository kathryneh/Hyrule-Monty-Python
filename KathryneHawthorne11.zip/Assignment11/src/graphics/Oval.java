package graphics;

public class Oval extends ObservedGraphic implements Graphicable {

	public Oval(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

}
