package graphics;

import java.beans.PropertyChangeListener;

public interface GraphicsObserver {
		public void addPropertyChangeListener(PropertyChangeListener listener);
}


