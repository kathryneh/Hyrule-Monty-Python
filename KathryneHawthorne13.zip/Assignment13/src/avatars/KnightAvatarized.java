package avatars;

import graphics.Line;

public interface KnightAvatarized extends Avatarized {
	public Line getSword();
}
