package tokens;


public class MoveCommandToken extends CommandToken implements Tokenizable {

	public MoveCommandToken(String newInput) {
		super(newInput);
	}

}
