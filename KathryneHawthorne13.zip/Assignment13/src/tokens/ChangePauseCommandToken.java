package tokens;


public class ChangePauseCommandToken extends CommandToken {

	public ChangePauseCommandToken(String newInput) {
		super(newInput);
	}

}
