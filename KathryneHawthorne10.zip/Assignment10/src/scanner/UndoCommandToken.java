package scanner;

public class UndoCommandToken extends CommandToken implements Tokenizable {

	public UndoCommandToken(String newInput) {
		super(newInput);
	}

}
