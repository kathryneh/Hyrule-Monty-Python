package scanner;

public class SayCommandToken extends CommandToken implements Tokenizable {

	public SayCommandToken(String newInput) {
		super(newInput);
		// TODO Auto-generated constructor stub
	}

}
