package graphics;

public interface Labelable extends Graphicable {
	public String getImageFileName();

	public void setImageFileName(String newVal);
}
