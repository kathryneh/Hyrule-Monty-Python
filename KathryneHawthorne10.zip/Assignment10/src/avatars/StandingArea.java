package avatars;

import graphics.Oval;

public interface StandingArea {
	public Oval standingArea();
}
